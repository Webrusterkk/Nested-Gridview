﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.Web.UI.WebControls
Partial Class VBSample
    Inherits System.Web.UI.Page
    Private con As New SqlConnection("Data Source=SureshDasari;Integrated Security=true;Initial Catalog=MySampleDB")

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
        If Not IsPostBack Then
            BindGridview()
        End If
    End Sub
    ' This method is used to bind gridview from database
    Protected Sub BindGridview()
        con.Open()
        Dim cmd As New SqlCommand("select TOP 4 CountryId,CountryName from Country", con)
        Dim da As New SqlDataAdapter(cmd)
        Dim ds As New DataSet()
        da.Fill(ds)
        con.Close()
        gvParentGrid.DataSource = ds
        gvParentGrid.DataBind()

    End Sub
    Protected Sub gvUserInfo_RowDataBound(ByVal sender As Object, ByVal e As GridViewRowEventArgs)
        If e.Row.RowType = DataControlRowType.DataRow Then
            con.Open()
            Dim gv As GridView = DirectCast(e.Row.FindControl("gvChildGrid"), GridView)
            Dim CountryId As Integer = Convert.ToInt32(e.Row.Cells(1).Text)
            Dim cmd As New SqlCommand("select * from State where CountryID=" & CountryId, con)
            Dim da As New SqlDataAdapter(cmd)
            Dim ds As New DataSet()
            da.Fill(ds)
            con.Close()
            gv.DataSource = ds
            gv.DataBind()
        End If
    End Sub
End Class
